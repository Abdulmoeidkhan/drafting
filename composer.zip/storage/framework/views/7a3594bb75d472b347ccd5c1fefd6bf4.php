<div
    wire:poll.1s="pollActiveRound"
    x-data="{
        broadcastActive: false,
        echoSubscribed: false,
        channelName: 'draft.league.<?php echo e($leagueType); ?>',
        subscribe() {
            if (this.echoSubscribed || typeof window.Echo === 'undefined') return;
            try {
                const pusher = window.Echo.connector?.pusher;
                if (pusher) {
                    if (pusher.connection.state === 'connected') {
                        this.broadcastActive = true;
                    } else {
                        pusher.connection.bind('connected', () => {
                            this.broadcastActive = true;
                        });
                    }
                }
                window.Echo.channel(this.channelName)
                    .listen('.draft.turn.changed', () => {
                        this.broadcastActive = true;
                        $wire.$refresh();
                    });
                this.echoSubscribed = true;
            } catch (e) {
                this.echoSubscribed = false;
            }
        }
    }"
    x-init="subscribe(); setInterval(() => { if (!echoSubscribed) subscribe(); }, 5000)"
>
    <div class="d-flex flex-column flex-lg-row justify-content-between align-items-lg-center gap-2 mb-3">
        <div>
            <h4 class="mb-1"><i class="bi bi-list-check"></i> Draft Rounds</h4>
            <p class="text-muted small mb-0">Each round every team picks one player in the order defined by the League Setup. Rounds auto-advance when all teams have picked.</p>
        </div>
        <a href="<?php echo e(route('admin.teams', ['tab' => 'categories', 'league' => $leagueType])); ?>" class="btn btn-outline-secondary btn-sm">
            Manage Categories
        </a>
    </div>

    <div class="round-setup-card mb-4">
        <h5 class="mb-3"><i class="bi bi-gear"></i> Draft Round Setup</h5>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($activeRound): ?>
            <div class="alert alert-info mb-0">
                <div class="d-flex flex-column flex-lg-row justify-content-between gap-3 align-items-lg-center">
                    <div>
                        <strong>Active Round:</strong>
                        <?php echo e($activeRound->category?->name); ?>

                        <span class="mx-1">|</span>
                        Current Turn: <strong><?php echo e($activeRound->currentTeam?->name); ?></strong>
                        <span class="mx-1">|</span>
                        Pick <?php echo e($activeRound->current_pick_number); ?> / <?php echo e(collect($activeRound->pick_order)->map(fn ($id) => (int) $id)->filter(fn ($id) => $id > 0)->count()); ?>

                        <span class="mx-1">|</span>
                        Timer: <strong><?php echo e(sprintf('%02d:%02d / %02d:%02d', intdiv($activeRoundRemainingSeconds, 60), $activeRoundRemainingSeconds % 60, intdiv((int) $activeRound->turn_time_seconds, 60), ((int) $activeRound->turn_time_seconds) % 60)); ?></strong>
                    </div>
                    <form method="POST" action="<?php echo e(route('admin.draft.round.close', $activeRound->id)); ?>" onsubmit="return confirm('Close the active round now?');">
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-sm btn-outline-danger" type="submit">Close Round</button>
                    </form>
                </div>
            </div>
        <?php else: ?>
            <form method="POST" action="<?php echo e(route('admin.draft.round.start')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="league_type" value="<?php echo e($leagueType); ?>">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!$leagueRoundConfigs->count()): ?>
                    <div class="alert alert-warning mb-0">
                        <i class="bi bi-exclamation-triangle"></i>
                        Configure the <a href="<?php echo e(route('admin.teams', ['tab' => 'league-setup', 'league' => $leagueType])); ?>">League Setup</a> first &mdash; it defines max players, number of rounds, and the pick order.
                    </div>
                <?php elseif($nextLeagueRoundNumber > $totalLeagueRounds): ?>
                    <div class="alert alert-success mb-0">
                        <i class="bi bi-trophy"></i>
                        All <strong><?php echo e($totalLeagueRounds); ?></strong> league rounds have been completed. The draft is finished.
                    </div>
                <?php else: ?>
                    <div class="row g-3">
                        <div class="col-12">
                            <div class="alert alert-info mb-0 py-2">
                                <strong>Round <?php echo e($nextLeagueRoundNumber); ?> of <?php echo e($totalLeagueRounds); ?></strong> &mdash; Pick order:
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($nextLeagueRoundConfig): ?>
                                    <span class="ms-1 d-inline-flex flex-wrap gap-1">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $nextLeagueRoundConfig->team_pick_order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pos => $tId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                        <?php $pt = $teamsById->get((int)$tId); $ptc = $pt?->color ?? '#6c757d'; ?>
                                        <span class="badge" style="background:<?php echo e($ptc); ?>;color:#fff;"><?php echo e($pos+1); ?>. <?php echo e($pt?->name ?? 'Unknown'); ?></span>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                    </span>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <label class="form-label">Primary Category</label>
                            <select name="category_id" class="form-select" required>
                                <option value="">Select category</option>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </select>
                        </div>
                        <div class="col-lg-3">
                            <label class="form-label">Allow Also From (Higher)</label>
                            <select name="higher_category_ids[]" class="form-select" multiple>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </select>
                            <div class="form-text">Optional. Hold Ctrl/Cmd to select multiple.</div>
                        </div>
                        <div class="col-lg-2">
                            <label class="form-label">Picks Per Team</label>
                            <input type="hidden" name="picks_per_team" value="1">
                            <input type="text" class="form-control" value="1 Player (fixed)" readonly>
                        </div>
                        <div class="col-lg-2">
                            <label class="form-label">Turn Time</label>
                            <select name="turn_time_seconds" class="form-select" required>
                                <option value="30">1/5 Minutes</option>
                                <option value="60">1 Minutes</option>
                                <option value="120">2 Minutes</option>
                                <option value="150" selected>2.5 Minutes</option>
                                <option value="180">3 Minutes</option>
                                <option value="240">4 Minutes</option>
                                <option value="300">5 Minutes</option>
                            </select>
                        </div>
                        <div class="col-lg-1 d-flex align-items-end">
                            <button class="btn btn-primary w-100" type="submit">Start Round <?php echo e($nextLeagueRoundNumber); ?></button>
                        </div>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </form>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($activeRound): ?>
        <div class="mb-4">
            <h6 class="mb-2">Round Progress By Team</h6>
            <div class="table-responsive">
                <table class="table align-middle mb-0">
                    <thead>
                        <tr>
                            <th>Team</th>
                            <th>Picks This Round</th>
                            <th>Target</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <?php
                                $teamPicks = $activeRoundTeamPickCounts[$team->id] ?? 0;
                                $isTurn = (int) $activeRound->current_team_id === (int) $team->id;
                                $turnProcessed = in_array((int) $team->id, array_map('intval', $activeRoundProcessedTeamIds ?? []), true);
                            ?>
                            <tr>
                                <td><?php echo e($team->name); ?></td>
                                <td><?php echo e($teamPicks); ?></td>
                                <td><?php echo e($activeRound->picks_per_team); ?></td>
                                <td>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isTurn): ?>
                                        <span class="badge text-bg-primary">Current Turn</span>
                                    <?php elseif($teamPicks >= $activeRound->picks_per_team): ?>
                                        <span class="badge text-bg-success">Completed</span>
                                    <?php elseif($turnProcessed): ?>
                                        <span class="badge text-bg-warning">Turn Skipped</span>
                                    <?php else: ?>
                                        <span class="badge text-bg-secondary">Waiting</span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                            </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <ul class="nav nav-pills draft-category-tabs mb-3" id="draftCategoryTabs" role="tablist">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <li class="nav-item" role="presentation">
                <button
                    class="nav-link <?php echo e($selectedCategoryKey === (string) $category->id ? 'active' : ''); ?>"
                    id="draft-category-<?php echo e($category->id); ?>-tab"
                    type="button"
                    role="tab"
                    wire:click="selectCategory('<?php echo e($category->id); ?>')"
                    data-category-key="<?php echo e($category->id); ?>"
                >
                    <?php echo e($category->name); ?>

                    <span class="category-count-badge"><?php echo e($category->draftable_participants_count); ?></span>
                </button>
            </li>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        <li class="nav-item" role="presentation">
            <button
                class="nav-link <?php echo e($selectedCategoryKey === 'uncategorized' ? 'active' : ''); ?>"
                id="draft-category-uncategorized-tab"
                type="button"
                role="tab"
                wire:click="selectCategory('uncategorized')"
                data-category-key="uncategorized"
            >
                Uncategorized
                <span class="category-count-badge"><?php echo e($uncategorizedDraftableParticipants->count()); ?></span>
            </button>
        </li>
    </ul>

    <div class="tab-content" id="draftCategoryTabContent">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <div class="tab-pane fade <?php echo e($selectedCategoryKey === (string) $category->id ? 'show active' : ''); ?>" id="draft-category-<?php echo e($category->id); ?>" role="tabpanel" tabindex="0">
                <div class="draft-round-header">
                    <div>
                        <h5 class="mb-1"><?php echo e($category->name); ?> Round</h5>
                        <p class="text-muted small mb-0">Only approved undrafted players from this category are available.</p>
                    </div>
                    <span class="badge text-bg-light"><?php echo e($category->draftable_participants_count); ?> available</span>
                </div>
                <div class="table-responsive">
                    <table class="table align-middle">
                        <thead>
                            <tr>
                                <th>Photo</th>
                                <th>Player</th>
                                <th>Email</th>
                                <th>Skill Category</th>
                                <th>City</th>
                                <th>Draft To Team</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $category->participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                <tr>
                                    <td>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($participant->passport_picture): ?>
                                            <img
                                                src="<?php echo e(asset('storage/' . ltrim($participant->passport_picture, '/'))); ?>"
                                                alt="<?php echo e($participant->full_name); ?>"
                                                class="rounded"
                                                style="width: 44px; height: 44px; object-fit: cover;"
                                            >
                                        <?php else: ?>
                                            <span class="badge text-bg-secondary">No Photo</span>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </td>
                                    <td><?php echo e($participant->full_name); ?></td>
                                    <td><?php echo e($participant->email); ?></td>
                                    <td>
                                        <?php $participantSkills = collect($participant->skill_categories ?? [])->filter()->values()->all(); ?>
                                        <div><strong><?php echo e($participant->category?->name ?: 'Uncategorized'); ?></strong></div>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($participantSkills)): ?>
                                            <div class="d-flex flex-wrap gap-1 mt-1">
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $participantSkills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                                    <span class="badge text-bg-light border"><?php echo e($skill); ?></span>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                            </div>
                                        <?php else: ?>
                                            <small class="text-muted">No specific skills</small>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </td>
                                    <td><?php echo e($participant->city); ?></td>
                                    <td>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($activeRound): ?>
                                            <?php
                                                $isEligible = in_array((int) $category->id, array_map('intval', $activeRoundEligibleCategoryIds), true);
                                                $currentTeam = $teams->firstWhere('id', $activeRound->current_team_id);
                                            ?>

                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isEligible && $currentTeam): ?>
                                                <form method="POST" action="<?php echo e(route('admin.draft.round.pick', [$activeRound->id, $participant->id])); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <button class="btn btn-sm btn-primary" type="submit">
                                                        Pick For <?php echo e($currentTeam->name); ?>

                                                    </button>
                                                </form>
                                            <?php elseif(!$isEligible): ?>
                                                <span class="badge text-bg-secondary">Not in round eligibility</span>
                                            <?php else: ?>
                                                <span class="badge text-bg-secondary">No current team</span>
                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        <?php elseif($teams->count() > 0): ?>
                                            <div class="dropdown">
                                                <button class="btn btn-sm btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                                    Draft (Legacy)
                                                </button>
                                                <ul class="dropdown-menu">
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                                        <li>
                                                            <form method="POST" action="<?php echo e(route('admin.team.draft', [$team->id, $participant->id])); ?>">
                                                                <?php echo csrf_field(); ?>
                                                                <button class="dropdown-item" type="submit">
                                                                    <?php echo e($team->name); ?> (<?php echo e($team->participants_count); ?>/<?php echo e($team->max_players); ?>)
                                                                </button>
                                                            </form>
                                                        </li>
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                                </ul>
                                            </div>
                                        <?php else: ?>
                                            <span class="badge text-bg-secondary">Create team first</span>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </td>
                                </tr>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                <tr>
                                    <td colspan="6" class="text-center text-muted py-4">No available players in this category round.</td>
                                </tr>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>

        <div class="tab-pane fade <?php echo e($selectedCategoryKey === 'uncategorized' ? 'show active' : ''); ?>" id="draft-category-uncategorized" role="tabpanel" tabindex="0">
            <div class="draft-round-header">
                <div>
                    <h5 class="mb-1">Uncategorized Round</h5>
                    <p class="text-muted small mb-0">Players here need no category or can be drafted from this fallback pool.</p>
                </div>
                <span class="badge text-bg-light"><?php echo e($uncategorizedDraftableParticipants->count()); ?> available</span>
            </div>
            <div class="table-responsive">
                <table class="table align-middle">
                    <thead>
                        <tr>
                            <th>Photo</th>
                            <th>Player</th>
                            <th>Email</th>
                            <th>Skill Category</th>
                            <th>City</th>
                            <th>Draft To Team</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $uncategorizedDraftableParticipants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <tr>
                                <td>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($participant->passport_picture): ?>
                                        <img
                                            src="<?php echo e(asset('storage/' . ltrim($participant->passport_picture, '/'))); ?>"
                                            alt="<?php echo e($participant->full_name); ?>"
                                            class="rounded"
                                            style="width: 44px; height: 44px; object-fit: cover;"
                                        >
                                    <?php else: ?>
                                        <span class="badge text-bg-secondary">No Photo</span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                                <td><?php echo e($participant->full_name); ?></td>
                                <td><?php echo e($participant->email); ?></td>
                                <td>
                                    <?php $uncatSkills = collect($participant->skill_categories ?? [])->filter()->values()->all(); ?>
                                    <div><strong><?php echo e($participant->category?->name ?: 'Uncategorized'); ?></strong></div>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($uncatSkills)): ?>
                                        <div class="d-flex flex-wrap gap-1 mt-1">
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $uncatSkills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                                <span class="badge text-bg-light border"><?php echo e($skill); ?></span>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                        </div>
                                    <?php else: ?>
                                        <small class="text-muted">No specific skills</small>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                                <td><?php echo e($participant->city); ?></td>
                                <td>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($activeRound): ?>
                                        <span class="badge text-bg-secondary">Uncategorized is not part of active round rules</span>
                                    <?php elseif($teams->count() > 0): ?>
                                        <div class="dropdown">
                                            <button class="btn btn-sm btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                                Draft
                                            </button>
                                            <ul class="dropdown-menu">
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                                    <li>
                                                        <form method="POST" action="<?php echo e(route('admin.team.draft', [$team->id, $participant->id])); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <button class="dropdown-item" type="submit">
                                                                <?php echo e($team->name); ?> (<?php echo e($team->participants_count); ?>/<?php echo e($team->max_players); ?>)
                                                            </button>
                                                        </form>
                                                    </li>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                            </ul>
                                        </div>
                                    <?php else: ?>
                                        <span class="badge text-bg-secondary">Create team first</span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                            </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            <tr>
                                <td colspan="6" class="text-center text-muted py-4">No uncategorized players available.</td>
                            </tr>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\HERD\ParticpantManagmentSystem\resources\views\livewire\draft-board.blade.php ENDPATH**/ ?>