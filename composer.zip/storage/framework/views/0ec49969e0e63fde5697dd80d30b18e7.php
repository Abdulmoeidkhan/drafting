<div
    wire:poll.1s="pollActiveRound"
    x-data="{
        broadcastActive: false,
        echoSubscribed: false,
        channelName: 'draft.league.<?php echo e($leagueType); ?>',
        subscribe() {
            if (this.echoSubscribed || typeof window.Echo === 'undefined') return;
            try {
                const pusher = window.Echo.connector?.pusher;
                if (pusher) {
                    if (pusher.connection.state === 'connected') {
                        this.broadcastActive = true;
                    } else {
                        pusher.connection.bind('connected', () => {
                            this.broadcastActive = true;
                        });
                    }
                }
                window.Echo.channel(this.channelName)
                    .listen('.draft.turn.changed', () => {
                        this.broadcastActive = true;
                        $wire.$refresh();
                    });
                this.echoSubscribed = true;
            } catch (e) {
                this.echoSubscribed = false;
            }
        }
    }"
    x-init="subscribe(); setInterval(() => { if (!echoSubscribed) subscribe(); }, 5000)"
>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->has('pick')): ?>
        <div class="alert alert-danger py-2 mb-3"><?php echo e($errors->first('pick')); ?></div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <h5 class="mb-3">Active Draft Round</h5>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($activeRound): ?>
        <p class="mb-1"><strong>Category:</strong> <?php echo e($activeRound->category?->name ?: 'N/A'); ?></p>
        <p class="mb-1"><strong>Current Team:</strong> <?php echo e($activeRound->currentTeam?->name ?: 'N/A'); ?></p>
        <p class="mb-1"><strong>Your Picks This Round:</strong> <?php echo e($teamRoundPicksCount); ?> / <?php echo e($activeRound->picks_per_team); ?></p>
        <p class="mb-3">
            <strong>Time Remaining:</strong>
            <span><?php echo e(sprintf('%02d:%02d / %02d:%02d', intdiv($activeRoundRemainingSeconds, 60), $activeRoundRemainingSeconds % 60, intdiv((int) $activeRound->turn_time_seconds, 60), ((int) $activeRound->turn_time_seconds) % 60)); ?></span>
        </p>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isTeamTurn): ?>
            <div class="alert alert-info py-2 mb-3">It is your turn to pick.</div>
        <?php else: ?>
            <div class="alert alert-secondary py-2 mb-3">Waiting for current team to finish their pick.</div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($draftPoolParticipants->count() > 0): ?>
            <div class="table-responsive">
                <table class="table table-striped align-middle mb-0">
                    <thead>
                        <tr>
                            <th>Photo</th>
                            <th>Player</th>
                            <th>Email</th>
                            <th>Skill Category</th>
                            <th class="text-end">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $draftPoolParticipants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                            <tr>
                                <td>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($player->passport_picture): ?>
                                        <img
                                            src="<?php echo e(asset('storage/' . ltrim($player->passport_picture, '/'))); ?>"
                                            alt="<?php echo e($player->full_name); ?>"
                                            class="rounded"
                                            style="width: 48px; height: 48px; object-fit: cover;"
                                        >
                                    <?php else: ?>
                                        <span class="badge text-bg-secondary">No Photo</span>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                                <td><?php echo e($player->full_name); ?></td>
                                <td><?php echo e($player->email); ?></td>
                                <td>
                                    <?php $playerSkills = collect($player->skill_categories ?? [])->filter()->values()->all(); ?>
                                    <div><strong><?php echo e($player->category?->name ?: 'Uncategorized'); ?></strong></div>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($playerSkills)): ?>
                                        <div class="d-flex flex-wrap gap-1 mt-1">
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $playerSkills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                                <span class="badge text-bg-light border"><?php echo e($skill); ?></span>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                        </div>
                                    <?php else: ?>
                                        <small class="text-muted">No specific skills</small>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                                <td class="text-end">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($canPick): ?>
                                        <button
                                            type="button"
                                            class="btn btn-sm btn-primary"
                                            wire:click="pickPlayer(<?php echo e($player->id); ?>)"
                                            wire:loading.attr="disabled"
                                            wire:target="pickPlayer(<?php echo e($player->id); ?>)"
                                        >
                                            <span wire:loading.remove wire:target="pickPlayer(<?php echo e($player->id); ?>)">Pick Player</span>
                                            <span wire:loading wire:target="pickPlayer(<?php echo e($player->id); ?>)">Picking...</span>
                                        </button>
                                    <?php else: ?>
                                        <button type="button" class="btn btn-sm btn-outline-secondary" disabled>Pick Player</button>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </td>
                            </tr>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p class="text-muted mb-0">No eligible players are currently available in this active round.</p>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php else: ?>
        <p class="text-muted mb-0">No active draft round right now.</p>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($draftActivity->count() > 0): ?>
        <hr class="my-4">
        <h5 class="mb-3">Recent Draft Activity</h5>
        <div class="table-responsive">
            <table class="table table-striped align-middle mb-0">
                <thead>
                    <tr>
                        <th>Time</th>
                        <th>Round</th>
                        <th>Pick #</th>
                        <th>Team</th>
                        <th>Player</th>
                        <th>Skill Category</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $draftActivity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <tr>
                            <td><?php echo e(optional($activity->picked_at)->format('M d, Y H:i') ?: '-'); ?></td>
                            <td>#<?php echo e($activity->draft_round_id); ?></td>
                            <td><?php echo e($activity->pick_number); ?></td>
                            <td><?php echo e($activity->team?->name ?: 'N/A'); ?></td>
                            <td><?php echo e($activity->participant?->full_name ?: 'N/A'); ?></td>
                            <td>
                                <?php
                                    $activityMainCategory = $activity->round?->category?->name ?: ($activity->participant?->category?->name ?: 'Uncategorized');
                                    $activitySkills = collect($activity->participant?->skill_categories ?? [])->filter()->values()->all();
                                ?>
                                <div><strong><?php echo e($activityMainCategory); ?></strong></div>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($activitySkills)): ?>
                                    <div class="d-flex flex-wrap gap-1 mt-1">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $activitySkills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                            <span class="badge text-bg-light border"><?php echo e($skill); ?></span>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                    </div>
                                <?php else: ?>
                                    <small class="text-muted">No specific skills</small>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </td>
                        </tr>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php /**PATH E:\HERD\ParticpantManagmentSystem\resources\views\livewire\team-draft-dashboard.blade.php ENDPATH**/ ?>