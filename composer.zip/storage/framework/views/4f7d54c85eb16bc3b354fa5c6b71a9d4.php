<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Teams & Draft - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/admin-teams.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/navbar.css')); ?>">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>
<body>
    <?php echo $__env->make('partials.portal-navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="container-fluid main-container" id="teamsPage" data-active-tab="<?php echo e($activeTab); ?>" data-active-draft-category="<?php echo e($activeDraftCategory); ?>" data-active-league="<?php echo e($activeLeagueType); ?>">
        <div class="page-header">
            <h1><i class="bi bi-trophy"></i> Team Module</h1>
            <p>Teams are managed here and players can only be assigned through drafting.</p>
            <div class="d-flex flex-wrap align-items-center gap-2 mt-2">
                <span class="badge text-bg-dark">Active League: <?php echo e($activeLeagueLabel); ?></span>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = ($availableLeagues ?? collect()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $league): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <a href="<?php echo e(route('admin.teams', ['tab' => $activeTab, 'category' => $activeDraftCategory, 'league' => $league->slug])); ?>"
                       class="btn btn-sm <?php echo e($activeLeagueType === $league->slug ? 'btn-primary' : 'btn-outline-primary'); ?>">
                        <?php echo e($league->name); ?>

                    </a>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </div>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('error')): ?>
            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('account_credentials')): ?>
            <?php
                $credentials = session('account_credentials');
            ?>
            <div class="alert alert-warning">
                <strong><?php echo e($credentials['label'] ?? 'New Account'); ?> Credentials:</strong>
                <div>Email: <code><?php echo e($credentials['email'] ?? ''); ?></code></div>
                <div>Password: <code><?php echo e($credentials['password'] ?? ''); ?></code></div>
                <small class="text-muted">Share these once and ask user to change password after first login.</small>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Please fix the following:</strong>
                <ul class="mb-0 mt-2">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <li><?php echo e($error); ?></li>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </ul>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <div class="card section-card mb-4">
            <div class="card-body">
                <ul class="nav nav-tabs" id="teamTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="teams-tab" data-bs-toggle="tab" data-bs-target="#teams-tab-pane" type="button" role="tab">
                            <i class="bi bi-shield"></i> Teams
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="draft-tab" data-bs-toggle="tab" data-bs-target="#draft-tab-pane" type="button" role="tab">
                            <i class="bi bi-list-check"></i> Draft Pool
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="drafted-tab" data-bs-toggle="tab" data-bs-target="#drafted-tab-pane" type="button" role="tab">
                            <i class="bi bi-collection"></i> Drafted Players
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="categories-tab" data-bs-toggle="tab" data-bs-target="#categories-tab-pane" type="button" role="tab">
                            <i class="bi bi-tags"></i> Categories
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="league-setup-tab" data-bs-toggle="tab" data-bs-target="#league-setup-tab-pane" type="button" role="tab">
                            <i class="bi bi-calendar3"></i> League Setup
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($leagueRoundConfigs->isNotEmpty()): ?>
                                <span class="badge text-bg-primary ms-1"><?php echo e($leagueRoundConfigs->count()); ?></span>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </button>
                    </li>
                </ul>

                <div class="tab-content pt-4" id="teamTabsContent">
                    <div class="tab-pane fade show active" id="teams-tab-pane" role="tabpanel" tabindex="0">
                        <div class="row g-4">
                            <div class="col-lg-4">
                                <div class="sub-card">
                                    <h4><i class="bi bi-plus-circle"></i> Create Team</h4>
                                    <form method="POST" action="<?php echo e(route('admin.team.create')); ?>" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="league_type" value="<?php echo e($activeLeagueType); ?>">
                                        <div class="mb-3">
                                            <label class="form-label">Team Name</label>
                                            <input class="form-control" name="name" required>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Short Code</label>
                                            <input class="form-control" name="short_code" maxlength="10" placeholder="Optional">
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Captain Name</label>
                                            <input class="form-control" name="captain_name" placeholder="Optional">
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Team Login Email</label>
                                            <input type="email" class="form-control" name="email" required>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Team Logo</label>
                                            <input type="file" class="form-control" name="logo" accept="image/png,image/jpeg,image/jpg,image/webp">
                                            <div class="form-text">Optional. PNG, JPG, or WEBP up to 2MB.</div>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Team Color</label>
                                            <div class="d-flex align-items-center gap-2">
                                                <input type="color" class="form-control form-control-color" name="color" value="#6c757d" title="Pick team color">
                                                <span class="form-text mb-0">Used in pick-order badges and round tables.</span>
                                            </div>
                                        </div>
                                        <button class="btn btn-primary w-100" type="submit">Create Team</button>
                                    </form>
                                </div>
                            </div>

                            <div class="col-lg-8">
                                <div class="sub-card">
                                    <h4><i class="bi bi-list"></i> Existing Teams</h4>
                                    <p class="text-muted small mb-3">Players cannot be selected here directly. Use the Draft Pool tab.</p>
                                    <div class="table-responsive">
                                        <table class="table align-middle">
                                            <thead>
                                                <tr>
                                                    <th>Logo</th>
                                                    <th>Team</th>
                                                    <th>Captain</th>
                                                    <th>Roster</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                                    <tr>
                                                        <td>
                                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($team->logo): ?>
                                                                <img src="<?php echo e(asset('storage/' . $team->logo)); ?>" alt="<?php echo e($team->name); ?> logo" class="team-logo-thumb">
                                                            <?php else: ?>
                                                                <div class="team-logo-placeholder"><i class="bi bi-image"></i></div>
                                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <strong><?php echo e($team->name); ?></strong>
                                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($team->short_code): ?>
                                                                <div class="small text-muted"><?php echo e($team->short_code); ?></div>
                                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                        </td>
                                                        <td><?php echo e($team->captain_name ?: 'Not set'); ?></td>
                                                        <td><?php echo e($team->participants_count); ?> / <?php echo e($team->max_players); ?></td>
                                                        <td>
                                                            <span style="display:inline-block;width:28px;height:28px;border-radius:50%;background:<?php echo e($team->color ?? '#6c757d'); ?>;border:2px solid #dee2e6;" title="<?php echo e($team->color ?? '#6c757d'); ?>"></span>
                                                        </td>
                                                        <td class="actions-cell">
                                                            <button
                                                                class="btn btn-sm btn-outline-primary"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#editTeamModal"
                                                                data-id="<?php echo e($team->id); ?>"
                                                                data-name="<?php echo e($team->name); ?>"
                                                                data-short="<?php echo e($team->short_code); ?>"
                                                                data-captain="<?php echo e($team->captain_name); ?>"
                                                                data-email="<?php echo e($team->email); ?>"
                                                                data-league="<?php echo e($team->league_type ?? 'male'); ?>"
                                                                data-max="<?php echo e($team->max_players); ?>"
                                                                data-logo="<?php echo e($team->logo ? asset('storage/' . $team->logo) : ''); ?>"
                                                                data-color="<?php echo e($team->color ?? '#6c757d'); ?>"
                                                                onclick="setEditTeam(this)"
                                                            >
                                                                Edit
                                                            </button>
                                                            <form method="POST" action="<?php echo e(route('admin.team.delete', $team->id)); ?>" onsubmit="return confirm('Delete this team? Drafted players will return to draft pool.');">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                                <button class="btn btn-sm btn-outline-danger" type="submit">Delete</button>
                                                            </form>
                                                        </td>
                                                    </tr>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                                    <tr>
                                                        <td colspan="5" class="text-center text-muted py-4">No teams found. Create your first team.</td>
                                                    </tr>
                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="tab-pane fade" id="draft-tab-pane" role="tabpanel" tabindex="0">
                        <div class="sub-card">
                            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('draft-board', ['league-type' => $activeLeagueType]);

$__keyOuter = $__key ?? null;

$__key = 'draft-board-'.$activeLeagueType;
$__componentSlots = [];

$__key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-2079997989-0', $__key);

$__html = app('livewire')->mount($__name, $__params, $__key, $__componentSlots);

echo $__html;

unset($__html);
unset($__key);
$__key = $__keyOuter;
unset($__keyOuter);
unset($__name);
unset($__params);
unset($__componentSlots);
unset($__split);
?>
                        </div>
                    </div>

                    <div class="tab-pane fade" id="drafted-tab-pane" role="tabpanel" tabindex="0">
                        <div class="sub-card">
                            <h4><i class="bi bi-collection"></i> Drafted Players</h4>
                            <div class="table-responsive">
                                <table class="table align-middle">
                                    <thead>
                                        <tr>
                                            <th>Player</th>
                                            <th>Team</th>
                                            <th>Skill Category</th>
                                            <th>Drafted At</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $draftedParticipants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                            <tr>
                                                <td><?php echo e($participant->full_name); ?></td>
                                                <td><?php echo e($participant->team?->name); ?></td>
                                                <td>
                                                    <?php $draftedSkills = collect($participant->skill_categories ?? [])->filter()->values()->all(); ?>
                                                    <div><strong><?php echo e($participant->category?->name ?: 'Uncategorized'); ?></strong></div>
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($draftedSkills)): ?>
                                                        <div class="d-flex flex-wrap gap-1 mt-1">
                                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $draftedSkills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                                                <span class="badge text-bg-light border"><?php echo e($skill); ?></span>
                                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                                        </div>
                                                    <?php else: ?>
                                                        <small class="text-muted">No specific skills</small>
                                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                </td>
                                                <td><?php echo e(optional($participant->drafted_at)->format('M d, Y H:i')); ?></td>
                                                <td>
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($participant->team): ?>
                                                        <form method="POST" action="<?php echo e(route('admin.team.release', [$participant->team->id, $participant->id])); ?>" onsubmit="return confirm('Release this player back to draft pool?');">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button class="btn btn-sm btn-outline-warning" type="submit">Release</button>
                                                        </form>
                                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                            <tr>
                                                <td colspan="5" class="text-center text-muted py-4">No drafted players yet.</td>
                                            </tr>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="tab-pane fade" id="categories-tab-pane" role="tabpanel" tabindex="0">
                        <div class="row g-4">
                            <div class="col-lg-4">
                                <div class="sub-card">
                                    <h4><i class="bi bi-tag"></i> Create Category</h4>
                                    <form method="POST" action="<?php echo e(route('admin.category.create')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <div class="mb-3">
                                            <label class="form-label">Category Name</label>
                                            <input class="form-control" name="name" required>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Description</label>
                                            <textarea class="form-control" name="description" rows="3" placeholder="Optional"></textarea>
                                        </div>
                                        <button class="btn btn-primary w-100" type="submit">Create Category</button>
                                    </form>
                                </div>
                            </div>

                            <div class="col-lg-8">
                                <div class="sub-card">
                                    <div class="d-flex flex-column flex-lg-row justify-content-between align-items-lg-center gap-2 mb-3">
                                        <div>
                                            <h4 class="mb-1"><i class="bi bi-tags"></i> Player Categories</h4>
                                            <p class="text-muted small mb-0">These categories are linked to players and used to start category-wise draft rounds.</p>
                                        </div>
                                    </div>
                                    <div class="table-responsive">
                                        <table class="table align-middle">
                                            <thead>
                                                <tr>
                                                    <th>Category</th>
                                                    <th>Description</th>
                                                    <th>Players</th>
                                                    <th>Round</th>
                                                    <th>Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                                    <tr>
                                                        <td><strong><?php echo e($category->name); ?></strong></td>
                                                        <td><?php echo e($category->description ?: 'No description'); ?></td>
                                                        <td><?php echo e($category->participants_count); ?></td>
                                                        <td>
                                                            <a href="<?php echo e(route('admin.teams', ['tab' => 'draft', 'category' => $category->id, 'league' => $activeLeagueType])); ?>" class="btn btn-sm btn-outline-secondary">
                                                                Start Draft Round
                                                            </a>
                                                        </td>
                                                        <td class="actions-cell">
                                                            <button
                                                                class="btn btn-sm btn-outline-primary"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#editCategoryModal"
                                                                data-id="<?php echo e($category->id); ?>"
                                                                data-name="<?php echo e($category->name); ?>"
                                                                data-description="<?php echo e($category->description); ?>"
                                                                onclick="setEditCategory(this)"
                                                            >
                                                                Edit
                                                            </button>
                                                            <form method="POST" action="<?php echo e(route('admin.category.delete', $category->id)); ?>" onsubmit="return confirm('Delete this category? Linked players will become uncategorized.');">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                                <button class="btn btn-sm btn-outline-danger" type="submit">Delete</button>
                                                            </form>
                                                        </td>
                                                    </tr>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                                    <tr>
                                                        <td colspan="5" class="text-center text-muted py-4">No categories found. Create a category to start category-wise draft rounds.</td>
                                                    </tr>
                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="tab-pane fade" id="league-setup-tab-pane" role="tabpanel" tabindex="0">
                        <div class="sub-card">
                            <div class="d-flex flex-column flex-lg-row justify-content-between align-items-lg-center gap-2 mb-4">
                                <div>
                                    <h4 class="mb-1"><i class="bi bi-calendar3"></i> League Round Setup</h4>
                                    <p class="text-muted small mb-0">Pre-plan all draft rounds. Set the full pick order for Round 1 by dragging teams; subsequent rounds are auto-generated &mdash; first-pick team moves to last each round, 2nd becomes new first. Total rounds = max players per team.</p>
                                </div>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($leagueRoundConfigs->isNotEmpty()): ?>
                                    <form method="POST" action="<?php echo e(route('admin.league.setup.clear')); ?>" onsubmit="return confirm('Clear the entire league round plan?');">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="league_type" value="<?php echo e($activeLeagueType); ?>">
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-outline-danger btn-sm" type="submit"><i class="bi bi-trash"></i> Clear All Rounds</button>
                                    </form>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>

                            <div class="row g-4 mb-4">
                                <div class="col-lg-4">
                                    <div class="sub-card h-100">
                                        <h5><i class="bi bi-diagram-3"></i> Create League</h5>
                                        <form method="POST" action="<?php echo e(route('admin.leagues.store')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <div class="mb-3">
                                                <label class="form-label">League Name</label>
                                                <input class="form-control" name="name" placeholder="e.g. Legends League" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">League Slug</label>
                                                <input class="form-control" name="slug" placeholder="e.g. legends" required>
                                                <div class="form-text">Use lowercase letters, numbers, and dashes only.</div>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Description</label>
                                                <textarea class="form-control" name="description" rows="3" placeholder="Optional"></textarea>
                                            </div>
                                            <button class="btn btn-primary w-100" type="submit">Create League</button>
                                        </form>
                                    </div>
                                </div>
                                <div class="col-lg-8">
                                    <div class="sub-card h-100">
                                        <h5><i class="bi bi-list-stars"></i> Available Leagues</h5>
                                        <div class="table-responsive">
                                            <table class="table align-middle mb-0">
                                                <thead>
                                                    <tr>
                                                        <th>Name</th>
                                                        <th>Slug</th>
                                                        <th>Description</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = ($availableLeagues ?? collect()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $league): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                                        <tr>
                                                            <td><strong><?php echo e($league->name); ?></strong></td>
                                                            <td><code><?php echo e($league->slug); ?></code></td>
                                                            <td><?php echo e($league->description ?: '—'); ?></td>
                                                        </tr>
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                                        <tr>
                                                            <td colspan="3" class="text-center text-muted py-3">No leagues available yet.</td>
                                                        </tr>
                                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($teams->count() === 0): ?>
                                <div class="alert alert-warning mb-0">
                                    <i class="bi bi-exclamation-triangle"></i> Create at least one team before setting up league rounds.
                                </div>
                            <?php else: ?>
                                <div class="round-setup-card mb-4">
                                    <h5 class="mb-3">
                                        <i class="bi bi-gear"></i>
                                        <?php echo e($leagueRoundConfigs->isEmpty() ? 'Configure League Rounds' : 'Reconfigure League (replaces current plan)'); ?>

                                    </h5>
                                    <form method="POST" action="<?php echo e(route('admin.league.setup.save')); ?>" id="leagueSetupForm">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="league_type" value="<?php echo e($activeLeagueType); ?>">
                                        <?php
                                            $r1Config     = $leagueRoundConfigs->firstWhere('round_number', 1);
                                            $r1OrderIds   = $r1Config ? collect($r1Config->team_pick_order)->map(fn($id) => (int)$id)->all() : [];
                                            // Merge: saved order first, then any new teams not yet in saved order
                                            $savedTeamIds = collect($r1OrderIds);
                                            $allTeamIds   = $teams->pluck('id')->map(fn($id) => (int)$id);
                                            $newTeamIds   = $allTeamIds->diff($savedTeamIds);
                                            $orderedTeams = $savedTeamIds->merge($newTeamIds)
                                                ->map(fn($id) => $teams->firstWhere('id', $id))
                                                ->filter()
                                                ->values();
                                        ?>
                                        <div class="row g-3">
                                            <div class="col-lg-3">
                                                <label class="form-label fw-semibold">Max Players per Team</label>
                                                <input type="number" class="form-control" name="max_players" min="1" max="99"
                                                    value="<?php echo e($leagueRoundConfigs->count() ?: 16); ?>" required>
                                                <div class="form-text">Each team gets this many players. One round per player &mdash; total rounds = this number.</div>
                                            </div>
                                            <div class="col-lg-9">
                                                <label class="form-label fw-semibold">Round 1 &mdash; Draft Pick Order</label>
                                                <p class="form-text mb-2">Drag teams to set who picks first, second, etc. Rounds 2&ndash;<?php echo e($leagueRoundConfigs->count() ?: 16); ?> are auto-generated: first-pick team moves to last each round.</p>
                                                <ul id="round1SortableList" class="list-group" style="cursor:grab; user-select:none;">
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $orderedTeams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                                        <?php $teamColor = $t->color ?? '#6c757d'; ?>
                                                        <li class="list-group-item d-flex align-items-center gap-2 py-2"
                                                            data-team-id="<?php echo e($t->id); ?>"
                                                            style="border-left: 4px solid <?php echo e($teamColor); ?>;">
                                                            <span class="drag-handle text-muted me-1" style="cursor:grab;"><i class="bi bi-grip-vertical"></i></span>
                                                            <span class="pick-position-badge badge" style="background:<?php echo e($teamColor); ?>;color:#fff;"><?php echo e($idx + 1); ?></span>
                                                            <span style="display:inline-block;width:12px;height:12px;border-radius:50%;background:<?php echo e($teamColor); ?>;flex-shrink:0;"></span>
                                                            <span class="fw-semibold"><?php echo e($t->name); ?></span>
                                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($t->short_code): ?>
                                                                <small class="text-muted">(<?php echo e($t->short_code); ?>)</small>
                                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                            <input type="hidden" name="round1_order[]" value="<?php echo e($t->id); ?>">
                                                        </li>
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                                </ul>
                                                <div class="form-text mt-1"><i class="bi bi-info-circle"></i> Position 1 = first pick, last position = last pick in Round 1.</div>
                                            </div>
                                            <div class="col-12">
                                                <button class="btn btn-primary" type="submit">
                                                    <i class="bi bi-check2-circle"></i>
                                                    <?php echo e($leagueRoundConfigs->isEmpty() ? 'Generate All Rounds' : 'Regenerate Rounds'); ?>

                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>

                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($leagueRoundConfigs->isEmpty()): ?>
                                    <div class="text-center py-5 text-muted">
                                        <i class="bi bi-calendar-x" style="font-size: 2.5rem;"></i>
                                        <p class="mt-2 mb-0">No rounds planned yet. Fill out the form above to generate the league schedule.</p>
                                    </div>
                                <?php else: ?>
                                    <div class="table-responsive">
                                        <table class="table align-middle">
                                            <thead>
                                                <tr>
                                                    <th style="width:90px;">Round</th>
                                                    <th>Pick Order (First &rarr; Last)</th>
                                                    <th style="width:130px;">Type</th>
                                                    <th style="width:120px;">Status</th>
                                                    <th style="width:110px;">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $leagueRoundConfigs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $config): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                                    <?php
                                                        $roundStatus = 'planned';
                                                        if ($config->round_number < $nextLeagueRoundNumber) {
                                                            $roundStatus = 'completed';
                                                        } elseif ($config->round_number === $nextLeagueRoundNumber && $activeRound) {
                                                            $roundStatus = 'active';
                                                        }
                                                    ?>
                                                    <tr class="<?php echo e($roundStatus === 'active' ? 'table-primary' : ($roundStatus === 'completed' ? 'opacity-50' : '')); ?>">
                                                        <td class="fw-bold">Round <?php echo e($config->round_number); ?></td>
                                                        <td>
                                                            <div class="d-flex flex-wrap gap-1">
                                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $config->team_pick_order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pos => $teamId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                                                    <?php
                                                                        $pickTeam  = $teamsById->get((int)$teamId);
                                                                        $pickColor = $pickTeam?->color ?? '#6c757d';
                                                                        $isFirst   = $pos === 0;
                                                                        $isLast    = $pos === count($config->team_pick_order) - 1;
                                                                    ?>
                                                                    <span class="badge" style="background:<?php echo e($pickColor); ?>;color:#fff;<?php echo e($isFirst ? 'outline:2px solid #0d6efd;' : ''); ?>">
                                                                        <?php echo e($pos + 1); ?>. <?php echo e($pickTeam?->name ?? 'Unknown'); ?>

                                                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isFirst): ?><small class="ms-1">(first)</small><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isLast): ?><small class="ms-1">(last)</small><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                                    </span>
                                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($config->is_manually_set): ?>
                                                                <span class="badge text-bg-warning"><i class="bi bi-pencil"></i> Manual</span>
                                                            <?php else: ?>
                                                                <span class="badge text-bg-light text-dark"><i class="bi bi-arrow-repeat"></i> Auto</span>
                                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($roundStatus === 'completed'): ?>
                                                                <span class="badge text-bg-success">Completed</span>
                                                            <?php elseif($roundStatus === 'active'): ?>
                                                                <span class="badge text-bg-primary">Active</span>
                                                            <?php else: ?>
                                                                <span class="badge text-bg-secondary">Planned</span>
                                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($roundStatus !== 'completed'): ?>
                                                                <button
                                                                    class="btn btn-sm btn-outline-secondary"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#editLeagueRoundModal"
                                                                    data-round="<?php echo e($config->round_number); ?>"
                                                                    data-first-team="<?php echo e($config->team_pick_order[0] ?? ''); ?>"
                                                                    data-action="<?php echo e(route('admin.league.round.update', $config->round_number)); ?>"
                                                                >
                                                                    <i class="bi bi-pencil"></i> Override
                                                                </button>
                                                            <?php else: ?>
                                                                <span class="text-muted small">&mdash;</span>
                                                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                        </td>
                                                    </tr>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="mt-3">
                                        <small class="text-muted">
                                            <i class="bi bi-info-circle"></i>
                                            <strong>Rotation rule:</strong> The first-pick team from round N moves to last in round N+1; the 2nd team becomes the new first pick.
                                            Use <em>Override</em> to manually reorder any future round.
                                            The planned first-pick is automatically pre-selected when starting a draft round from the <em>Draft Pool</em> tab.
                                        </small>
                                    </div>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="editLeagueRoundModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Override First Pick &mdash; Round <span id="editLeagueRoundNumber"></span></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" id="editLeagueRoundForm">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="modal-body">
                        <input type="hidden" name="league_type" id="editLeagueRoundLeagueType" value="<?php echo e($activeLeagueType); ?>">
                        <p class="text-muted small mb-3">The remaining teams keep their relative order from the existing plan, rotated so the chosen team goes first.</p>
                        <div class="mb-3">
                            <label class="form-label">First Pick Team</label>
                            <select class="form-select" name="first_team_id" id="editLeagueRoundFirstTeam" required>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                    <option value="<?php echo e($team->id); ?>"><?php echo e($team->name); ?></option>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Save Override</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="editTeamModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Team</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" id="editTeamForm" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Current Logo</label>
                            <div id="edit_team_logo_preview" class="team-logo-preview-empty">
                                <i class="bi bi-image"></i>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Team Name</label>
                            <input class="form-control" id="edit_team_name" name="name" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Short Code</label>
                            <input class="form-control" id="edit_team_short_code" name="short_code" maxlength="10">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Captain Name</label>
                            <input class="form-control" id="edit_team_captain_name" name="captain_name">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Team Login Email</label>
                            <input type="email" class="form-control" id="edit_team_email" name="email" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">League</label>
                            <select class="form-select" id="edit_team_league_type" name="league_type" required>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = ($availableLeagues ?? collect()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $league): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                    <option value="<?php echo e($league->slug); ?>"><?php echo e($league->name); ?></option>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Replace Logo</label>
                            <input type="file" class="form-control" name="logo" accept="image/png,image/jpeg,image/jpg,image/webp">
                            <div class="form-text">Leave empty to keep the current logo.</div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Team Color</label>
                            <div class="d-flex align-items-center gap-2">
                                <input type="color" class="form-control form-control-color" id="edit_team_color" name="color" value="#6c757d" title="Pick team color">
                                <span class="form-text mb-0">Shown in pick-order badges and round tables.</span>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Update Team</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="editCategoryModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Category</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" id="editCategoryForm">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Category Name</label>
                            <input class="form-control" id="edit_category_name" name="name" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea class="form-control" id="edit_category_description" name="description" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Update Category</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php
        $adminBroadcastDriver = config('broadcasting.default');
        $adminBroadcastConnection = in_array($adminBroadcastDriver, ['reverb', 'pusher'], true)
            ? (array) config('broadcasting.connections.' . $adminBroadcastDriver, [])
            : [];
        $adminBroadcastConfig = [
            'enabled' => !empty($adminBroadcastConnection['key']),
            'channel' => 'draft.league.' . ($activeLeagueType ?? 'male'),
        ];
    ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.6/Sortable.min.js"></script>
    <script>
        // ── Round 1 sortable pick-order list ────────────────────────────────────
        (function () {
            const list = document.getElementById('round1SortableList');
            if (!list) return;

            function refreshPositionBadges() {
                list.querySelectorAll('li').forEach(function (li, idx) {
                    const badge = li.querySelector('.pick-position-badge');
                    if (badge) badge.textContent = idx + 1;
                    // update the hidden input value to current team id (already set, just ensure order)
                });
            }

            Sortable.create(list, {
                handle: '.drag-handle',
                animation: 150,
                ghostClass: 'list-group-item-primary',
                onEnd: refreshPositionBadges,
            });
        }());
    </script>
    <script>
        function setEditTeam(button) {
            const id = button.dataset.id;
            const logo = button.dataset.logo;
            document.getElementById('editTeamForm').action = '/admin/teams/' + id;
            document.getElementById('edit_team_name').value = button.dataset.name || '';
            document.getElementById('edit_team_short_code').value = button.dataset.short || '';
            document.getElementById('edit_team_captain_name').value = button.dataset.captain || '';
            document.getElementById('edit_team_email').value = button.dataset.email || '';
            document.getElementById('edit_team_league_type').value = button.dataset.league || 'male';
            document.getElementById('edit_team_color').value = button.dataset.color || '#6c757d';

            const preview = document.getElementById('edit_team_logo_preview');

            if (logo) {
                preview.className = 'team-logo-preview';
                preview.innerHTML = '<img src="' + logo + '" alt="Team logo preview">';
            } else {
                preview.className = 'team-logo-preview-empty';
                preview.innerHTML = '<i class="bi bi-image"></i>';
            }
        }

        function setEditCategory(button) {
            document.getElementById('editCategoryForm').action = '/admin/categories/' + button.dataset.id;
            document.getElementById('edit_category_name').value = button.dataset.name || '';
            document.getElementById('edit_category_description').value = button.dataset.description || '';
        }

        const leagueRoundModal = document.getElementById('editLeagueRoundModal');
        if (leagueRoundModal) {
            leagueRoundModal.addEventListener('show.bs.modal', function (event) {
                const button = event.relatedTarget;
                if (!button) return;
                const roundNumber = button.getAttribute('data-round');
                const firstTeamId = button.getAttribute('data-first-team');
                const actionUrl   = button.getAttribute('data-action');
                document.getElementById('editLeagueRoundNumber').textContent = roundNumber || '';
                const form = document.getElementById('editLeagueRoundForm');
                if (form && actionUrl) form.action = actionUrl;
                const select = document.getElementById('editLeagueRoundFirstTeam');
                if (select && firstTeamId) select.value = firstTeamId;
            });
        }

        document.addEventListener('DOMContentLoaded', function () {
            const page = document.getElementById('teamsPage');
            const activeTopTab = page?.dataset.activeTab || 'teams';
            const activeDraftCategory = page?.dataset.activeDraftCategory || 'uncategorized';
            const topTabButton = document.getElementById(activeTopTab + '-tab');
            const globalDraftRefreshKey = 'draft_force_refresh_at';
            let reloadScheduled = false;

            function reloadPage() {
                if (reloadScheduled) {
                    return;
                }

                reloadScheduled = true;
                const url = new URL(window.location.href);
                url.searchParams.set('_draft_refresh', String(Date.now()));
                window.location.replace(url.toString());
            }

            function triggerGlobalDraftRefresh() {
                try {
                    localStorage.setItem(globalDraftRefreshKey, String(Date.now()));
                } catch (error) {
                    console.warn('Unable to broadcast global draft refresh.', error);
                }
            }

            window.addEventListener('storage', function (event) {
                if (event.key !== globalDraftRefreshKey || !event.newValue) {
                    return;
                }

                if (document.visibilityState === 'visible') {
                    reloadPage();
                }
            });

            if (topTabButton) {
                bootstrap.Tab.getOrCreateInstance(topTabButton).show();
            }

            const draftCategoryButton = document.querySelector('[data-category-key="' + activeDraftCategory + '"]');
            const fallbackDraftCategoryButton = document.querySelector('#draftCategoryTabs .nav-link');

            if (draftCategoryButton) {
                bootstrap.Tab.getOrCreateInstance(draftCategoryButton).show();
            } else if (fallbackDraftCategoryButton) {
                bootstrap.Tab.getOrCreateInstance(fallbackDraftCategoryButton).show();
            }
        });
    </script>
<?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

</body>
</html><?php /**PATH E:\HERD\ParticpantManagmentSystem\resources\views\admin\teams.blade.php ENDPATH**/ ?>