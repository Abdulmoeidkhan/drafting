<?php
    $user = auth()->user();

    $brandHref = route('login');
    $brandLabel = 'Portal';

    if ($user) {
        if ($user->isAdmin()) {
            $brandHref = route('admin.dashboard');
            $brandLabel = 'Admin Panel';
        } elseif ($user->hasRole('team')) {
            $brandHref = route('team.dashboard');
            $brandLabel = 'Team Portal';
        } elseif ($user->hasRole('player')) {
            $brandHref = route('player.profile');
            $brandLabel = 'Player Portal';
        }
    }
?>

<nav class="navbar navbar-expand-lg navbar-dark sticky-top app-navbar">
    <div class="container-fluid">
        <a class="navbar-brand" href="<?php echo e($brandHref); ?>">
            <i class="bi bi-diagram-3"></i> <?php echo e($brandLabel); ?>

        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#portalNavbar" aria-controls="portalNavbar" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="portalNavbar">
            <ul class="navbar-nav ms-auto">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user && $user->isAdmin()): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('admin.dashboard')); ?>">
                            <i class="bi bi-house"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('admin.participants') || request()->routeIs('admin.participant.*') ? 'active' : ''); ?>" href="<?php echo e(route('admin.participants')); ?>">
                            <i class="bi bi-people"></i> Participants
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('admin.teams') ? 'active' : ''); ?>" href="<?php echo e(route('admin.teams')); ?>">
                            <i class="bi bi-shield"></i> Teams
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('admin.users') ? 'active' : ''); ?>" href="<?php echo e(route('admin.users')); ?>">
                            <i class="bi bi-person-gear"></i> Users
                        </a>
                    </li>
                <?php elseif($user && $user->hasRole('team')): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('team.dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('team.dashboard')); ?>">
                            <i class="bi bi-speedometer2"></i> Team Dashboard
                        </a>
                    </li>
                <?php elseif($user && $user->hasRole('player')): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('player.profile') ? 'active' : ''); ?>" href="<?php echo e(route('player.profile')); ?>">
                            <i class="bi bi-person-circle"></i> Player Profile
                        </a>
                    </li>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($user): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('activities.index') ? 'active' : ''); ?>" href="<?php echo e(route('activities.index')); ?>">
                            <i class="bi bi-activity"></i> Activities
                        </a>
                    </li>
                    <li class="nav-item">
                        <form method="POST" action="<?php echo e(route('logout')); ?>" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="nav-link" style="border: none; background: none; cursor: pointer;">
                                <i class="bi bi-box-arrow-right"></i> Logout
                            </button>
                        </form>
                    </li>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH E:\HERD\ParticpantManagmentSystem\resources\views\partials\portal-navbar.blade.php ENDPATH**/ ?>