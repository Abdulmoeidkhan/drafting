<?php

use Livewire\Component;

new class extends Component
{
    //
};
?>

<div>
    
</div><?php /**PATH E:\HERD\ParticpantManagmentSystem\resources\views\components\⚡team-draft-dashboard.blade.php ENDPATH**/ ?>